<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> - Candidates Create
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <!-- page-contain-start  -->
            <div class="integrations-div setting-profile-div">

                <div class="page__heading row align-items-center mb-0">
                    <div class="col-xl-12 mb-3 mb-md-0">
                        <div class="integrations-head">
                            <h2>Add Candidate</h2>
                        </div>
                    </div>
                </div>

                <div class="profile-div">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="integrations-form profile-form">
                                <form action="<?php echo e(route('candidates.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row g-2 justify-content-between">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label for="">Contact No: <span>*</span></label>
                                                <input type="text" class="form-control" id="contact_no" value=""
                                                    name="contact_no" value="<?php echo e(old('contact_no')); ?>" placeholder="">
                                                <?php if($errors->has('contact_no')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('contact_no')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row g-2 justify-content-between auto-fill">
                                        <?php echo $__env->make('candidates.auto-fill', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    </div>
                                    <div class="row g-2 justify-content-between ">
                                        <div class="col-lg-12">
                                            <div class="save-btn-div d-flex align-items-center">
                                                <button type="submit" class="btn save-btn">save</button>
                                                <a href="<?php echo e(route('candidates.index')); ?>"
                                                    class="btn save-btn save-btn-1">Cancel</a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page-contain-end  -->
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#contact_no').on('keyup', function() {
                var contact_no = $(this).val();
                if (contact_no.length >= 10) {
                    $.ajax({
                        url: "<?php echo e(route('candidates.auto-fill')); ?>",
                        type: "GET",
                        data: {
                            contact_no: contact_no
                        },
                        success: function(response) {
                            $('.auto-fill').html(response.view);
                        }
                    });
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '.referred_type', function() {
                var type = $(this).text();
                // alert(type);
                if (type == 'Associate') {
                    $('.referred_by_id').html(
                        `<label for="">Referred by <span><a href="javascript:void(0);" class="referred_type">Other</a></span></label>
                    <select name="referred_by_id" class="form-control" id="">
                        <option value="">Select Type</option>
                        <?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item['id']); ?>"><?php echo e($item['full_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>`
                    );
                } else {
                    $('.referred_by_id').html(
                        `<label for="">Referred by <span><a href="javascript:void(0);" class="referred_type">Associate</a></span></label>
                    <input type="text" class="form-control" id="" name="referred_by" placeholder="">`
                    );
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/candidates/create.blade.php ENDPATH**/ ?>