<?php $__env->startComponent('mail::message'); ?>
<h1>We have received your request to reset your account password</h1>
<p>You can click the following button to recover your account:</p>

<?php $__env->startComponent('mail::button', ['url' => route('reset.password', ['id'=>$details['id'],'token'=>$details['token']])]); ?>
    Reset Password
<?php echo $__env->renderComponent(); ?>


<p>The allowed duration of the code is one hour from the time the message was sent</p>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/emails/sendCodeResetPassword.blade.php ENDPATH**/ ?>