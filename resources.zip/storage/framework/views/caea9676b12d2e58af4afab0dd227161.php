<table class="table mb-0 table-bordered">
    <thead>
        <tr>
            
            <th>Remarks</th>
            <th>Enter By</th>
            <th>Status</th>
            <th>Mode of Registration</th>
            <th>Source</th>
            <th>Last Update Date</th>
            <th>Full Name</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Age</th>
            <th>Education</th>
            <th>Contact No:</th>
            <th>Alternate Contact No.</th>
            <th>Whatsapp No.</th>
            <th>Email ID</th>
            <th>Referred By</th>
            <th>Other Education</th>
            <th>City</th>
            <th>Religion</th>
            <th>ECR Type</th>
            <th>Indidan Driving Licence</th>
            <th>International Driving Licence</th>
            <th>English Speak</th>
            <th>Arabic Speak</th>
            <th>Return</th>
            <th>Post Applied For</th>
            <th>Position</th>
            <th>Indian Experience (If any?)</th>
            <th>Abroad Experience (If any?)</th>
            <th>Remarks</th>
        </tr>
    </thead>
    <tbody class="list" id="candidate_body">
        <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->remarks ?? 'N/A'); ?></td>
            <td><?php echo e($item->enterBy->full_name  ?? 'N/A'); ?></td>
            <td>
                <div class="round_staus active">
                    <?php echo e($item->candidateStatus->name  ?? 'N/A'); ?>

                </div>
            </td>
            <td><?php echo e($item->mode_of_registration ?? 'N/A'); ?></td>
            <td>
                <?php echo e($item->source ?? 'N/A'); ?>

            </td>
            <td><?php echo e($item->last_update_date != null ? date('d.m.Y', strtotime($item->last_update_date)) : 'N/A'); ?></td>
            <td><?php echo e($item->full_name  ?? 'N/A'); ?></td>
            <td><?php echo e($item->gender  ?? 'N/A'); ?></td>
            <td><?php echo e($item->date_of_birth != null ? date('d.m.Y', strtotime($item->date_of_birth)) : 'N/A'); ?></td>
            <td><?php echo e($item->age  ?? 'N/A'); ?></td>
            <td><?php echo e($item->education  ?? 'N/A'); ?></td>
            <td><?php echo e($item->contact_no  ?? 'N/A'); ?>

            </td>
            <td><?php echo e($item->alternate_contact_no ?? 'N/A'); ?>

            </td>
            <td><?php echo e($item->whatapp_no  ?? 'N/A'); ?></td>
            <td><?php echo e($item->email ?? 'N/A'); ?></td>
            <td> <?php if($item->referred_by_id != null): ?>
                <?php echo e($item->referredBy->full_name); ?>

            <?php else: ?>
                <?php echo e($item->referred_by); ?>

            <?php endif; ?></td>
            <td><?php echo e($item->other_education ?? 'N/A'); ?></td>
            <td><?php echo e($item->city ?? 'N/A'); ?>

            </td>
            <td><?php echo e($item->religion ?? 'N/A'); ?></td>
            <td><?php echo e($item->ecr_type ?? 'N/A'); ?></td>
            <td><?php echo e($item->indian_driving_license ?? 'N/A'); ?></td>
            <td><?php echo e($item->international_driving_license  ?? 'N/A'); ?></td>
            <td><?php echo e($item->english_speak ?? 'N/A'); ?></td>
            <td><?php echo e($item->arabic_speak ?? 'N/A'); ?></td>
            <td><?php echo e(($item->return == 1)? 'Yes' : 'N0'); ?></td>
            <td><?php echo e($item->candidatePositions->name ?? 'N/A'); ?></td>
            <td><?php echo e($item->position  ?? 'N/A'); ?></td>
            <td><?php echo e($item->indian_exp  ?? 'N/A'); ?></td>
            <td><?php echo e($item->abroad_exp ?? 'N/A'); ?></td>
            <td><?php echo e($item->remarks  ?? 'N/A'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/candidates/export.blade.php ENDPATH**/ ?>