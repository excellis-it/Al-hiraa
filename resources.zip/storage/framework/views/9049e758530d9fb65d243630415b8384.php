<?php if(count($candidates) > 0): ?>
    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Candidate')): ?> class="edit-route" data-route="<?php echo e(route('candidates.edit', $item['id'])); ?>" <?php endif; ?>>
            <td><?php echo e($item->remarks ?? 'N/A'); ?></td>
            <td><?php echo e($item->enterBy->full_name ?? 'N/A'); ?></td>
            <td>
                <div class="round_staus active">
                    <?php echo e($item->candidateStatus->name ?? 'N/A'); ?>

                </div>
            </td>
            <td><?php echo e($item->mode_of_registration ?? 'N/A'); ?></td>
            <td>
                <?php echo e($item->source ?? 'N/A'); ?>

            </td>
            <td><?php echo e($item->last_update_date != null ? date('d.m.Y', strtotime($item->last_update_date)) : 'N/A'); ?></td>
            <td><?php echo e($item->full_name ?? 'N/A'); ?></td>
            <td><?php echo e($item->gender ?? 'N/A'); ?></td>
            <td><?php echo e($item->date_of_birth != null ? date('d.m.Y', strtotime($item->date_of_birth)) : 'N/A'); ?></td>
            <td><?php echo e($item->age ?? 'N/A'); ?></td>
            <td><?php echo e($item->education ?? 'N/A'); ?></td>
            <td>*************</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="12" class="text-left">
            <div class="d-flex justify-content-between">
                <div class="">
                    (Showing <?php echo e($candidates->firstItem()); ?> – <?php echo e($candidates->lastItem()); ?> candidates of
                    <?php echo e($candidates->total()); ?> candidates)
                </div>
                <div><?php echo $candidates->links(); ?></div>
            </div>
        </td>
    </tr>
<?php else: ?>
    <tr>
        <td colspan="12" class="text-center">No Data Found</td>
    </tr>
<?php endif; ?>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/candidates/filter.blade.php ENDPATH**/ ?>