<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>
    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">
    <!-- Simplebar -->
    <link type="text/css" href="<?php echo e(asset('assets/css/simplebar.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('assets/bootstrap-5.0.2/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- App CSS -->
    <link type="text/css" href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <!-- Material Design Icons -->
    <link type="text/css" href="<?php echo e(asset('assets/css/vendor-material-icons.css')); ?>" rel="stylesheet">
    <!-- Font Awesome FREE Icons -->
    <link type="text/css" href="<?php echo e(asset('assets/css/vendor-fontawesome-free.css')); ?>" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>">
</head>

<body class="layout-login-centered-boxed">
    <div class="layout-login-centered-boxed__form">
        <h1>Hello;</h1>
        <div class="card p-5">
            <form method="POST" action="<?php echo e(route('login.check')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label class="text-label" for="email_2">Email</label>
                    <div class="input-group input-group-merge">
                        <input id="email_2" type="email" class="form-control form-control-prepended" name="email"
                            placeholder="">
                    </div>
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label class="text-label" for="password_2">Password</label>
                    <div class="input-group input-group-merge">
                        <input id="password_2" type="password" name="password"
                            class="form-control form-control-prepended" placeholder="">
                    </div>
                    <?php if($errors->has('password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        
                    </div>
                    <div class="col-md-6">
                        <div class="form-group text-end">
                            <a href="<?php echo e(route('forget.password.show')); ?>" class="forgot_password">Forgot password?</a>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <button class="btn btn-login" type="submit">Sign in</button>
                </div>

            </form>
        </div>
    </div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('assets/bootstrap-5.0.2/js/bootstrap.bundle.js')); ?>"></script>
    <!-- Simplebar -->
    <script src="<?php echo e(asset('assets/js/simplebar.min.js')); ?>"></script>
    <!-- App -->
    <script src="<?php echo e(asset('assets/js/toggle-check-all.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/check-selected-row.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sidebar-mini.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <!-- App Settings (safe to remove) -->
    <script src="<?php echo e(asset('assets/js/app-settings.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>

    <script>
        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>

</body>

</html>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/auth/login.blade.php ENDPATH**/ ?>