<?php if(count($members) > 0): ?>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="edit-route" data-route="<?php echo e(route('members.edit', $member['id'])); ?>">
                <span class="user-icon">
                    <?php if($member->profile_picture): ?>
                        <img src="<?php echo e(Storage::url($member->profile_picture)); ?>" class="table-img" alt="">
                    <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24">
                            <g id="Group_86" data-name="Group 86" transform="translate(-435.5 -219)">
                                <g id="Ellipse_85" data-name="Ellipse 85" transform="translate(435.5 219)"
                                    fill="#fff" stroke="#d9d9d9" stroke-width="1">
                                    <ellipse cx="12.5" cy="12" rx="12.5" ry="12"
                                        stroke="none" />
                                    <ellipse cx="12.5" cy="12" rx="12" ry="11.5"
                                        fill="none" />
                                </g>
                                <g id="user" transform="translate(444.352 226)">
                                    <ellipse id="Ellipse_12" data-name="Ellipse 12" cx="2.588" cy="2.588"
                                        rx="2.588" ry="2.588" transform="translate(1.122 0)" fill="#6a6a6a" />
                                    <path id="Path_28" data-name="Path 28"
                                        d="M67.882,298.667A3.887,3.887,0,0,0,64,302.549a.431.431,0,0,0,.431.431h6.9a.431.431,0,0,0,.431-.431A3.887,3.887,0,0,0,67.882,298.667Z"
                                        transform="translate(-64 -292.628)" fill="#6a6a6a" />
                                </g>
                            </g>
                        </svg>
                    <?php endif; ?>

                </span>
                <?php echo e($member->full_name); ?>

            </td>
            <td <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Team')): ?> class="edit-route" data-route="<?php echo e(route('members.edit', $member['id'])); ?>" <?php endif; ?>>
                <?php echo e(date('d/m/Y', strtotime($member->created_at))); ?></td>
            <td <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Team')): ?> class="edit-route" data-route="<?php echo e(route('members.edit', $member['id'])); ?>" <?php endif; ?>>
                <?php echo e($member->phone); ?></td>
            <td <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Team')): ?> class="edit-route" data-route="<?php echo e(route('members.edit', $member['id'])); ?>" <?php endif; ?>>
                <?php echo e($member->email); ?></td>
            <td <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Team')): ?> class="edit-route" data-route="<?php echo e(route('members.edit', $member['id'])); ?>" <?php endif; ?>>
                <?php echo e($member->getRoleNames()->first()); ?>

            </td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Team')): ?>
            <td>
                <a title="Delete User" data-route="<?php echo e(route('members.delete', Crypt::encrypt($member->id))); ?>"
                    href="javascipt:void(0);" id="delete"> <span class="trash-icon"><i
                            class="fas fa-trash"></i></span></a>
            </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="6" class="text-left">
            <div class="d-flex justify-content-between">
                <div class="">
                     (Showing <?php echo e($members->firstItem()); ?> – <?php echo e($members->lastItem()); ?> members of
                    <?php echo e($members->total()); ?> members)
                </div>
                <div><?php echo $members->links(); ?></div>
            </div>
        </td>
    </tr>
<?php else: ?>
    <tr>
        <td colspan="6" class="text-center">No Data Found</td>
    </tr>
<?php endif; ?>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/settings/members/filter.blade.php ENDPATH**/ ?>