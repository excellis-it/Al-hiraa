<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">
    <!-- Simplebar -->
    <link type="text/css" href="<?php echo e(asset('assets/css/simplebar.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        rel="stylesheet">
    <!-- Slider -->
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" />
    <link type="text/css" href="<?php echo e(asset('assets/bootstrap-5.0.2/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="layout-default">
    
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('candidates.import')); ?>" method="POST" id="candidate-form-import"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            

                            <div class="row mb-3">
                                <div class="col-md-12 mb-6">
                                    <label class="form-label">Download sample candidate CSV file</label>
                                    <a href="<?php echo e(route('candidates.download.sample')); ?>"
                                        class="btn btn-sm btn-primary rounded">
                                        <i class="ti ti-download"></i> Download
                                    </a>
                                </div>
                            </div>

                            <input type="file" class="form-control" id="file" name="file"
                                style="height: auto">
                            <span class="text-danger" id="file-err"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        
                        <button type="submit" class="btn btn-primary">Import</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- <div class="preloader"></div> -->
    <!-- Header Layout -->
    <section id="loading">
        <div id="loading-content"></div>
    </section>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div id="header" class="mdk-header js-mdk-header m-0 d-block d-xl-none">
            <div class="mdk-header__content">
                <div class="navbar navbar-expand-sm navbar-main mdk-header--fixed" id="navbar"
                    data-primary="data-primary">
                    <div class="container-fluid p-0">
                        <div class="d-flex justify-content-between w-100 ps-3">
                            <a href="javascript:void(0);" class="">
                                <img class="navbar-brand-icon" src="<?php echo e(asset('assets/images/logo.png')); ?>"
                                    width="100" alt="">
                            </a>
                            <button class="navbar-toggler navbar-toggler-right d-block d-xl-none" type="button">
                                <span class="navbar-toggler-icon">
                                    <i class="fa-solid fa-bars-staggered"></i>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- // END Header -->
        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">
            <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push="" data-responsive-width="992px">
                <?php echo $__env->yieldContent('content'); ?>
                <!-- // END drawer-layout__content -->
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- // END drawer-layout -->
        </div>
        <!-- // END header-layout__content -->
    </div>
    <!-- // END header-layout -->
    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap-5.0.2/js/bootstrap.bundle.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script src="<?php echo e(asset('assets/js/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>

    <script>
        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/layouts/master.blade.php ENDPATH**/ ?>