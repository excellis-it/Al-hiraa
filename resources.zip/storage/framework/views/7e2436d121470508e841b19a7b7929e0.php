<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>