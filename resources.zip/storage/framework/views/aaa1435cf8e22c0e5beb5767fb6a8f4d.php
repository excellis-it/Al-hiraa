<?php if(isset($autofill)): ?>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Full Name <span>*</span></label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->full_name ?? ''); ?>" name="full_name"
                placeholder="">
            <?php if($errors->has('full_name')): ?>
                <span class="text-danger"><?php echo e($errors->first('full_name')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Email <span></span></label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->email ?? ''); ?>"
                name="email" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Alternative Contact No: </label>
            <input type="text" class="form-control" id="" name="alternate_contact_no"
                value="<?php echo e($candidate->alternate_contact_no ?? ''); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Whatsapp No: </label>
            <input type="text" class="form-control" id="" name="whatapp_no"
                value="<?php echo e($candidate->whatapp_no ?? ''); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">City: </label>
            <input type="text" class="form-control" id="" name="city"
                value="<?php echo e($candidate->city ?? ''); ?>" placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Gender</label>
            <select name="gender" class="form-select" id="">
                <option value="">Select Gender</option>
                <option value="Male" <?php echo e($candidate->gender == 'Male' ? 'selected' : ''); ?>> Male </option>
                <option value="Female" <?php echo e($candidate->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                <option value="Other" <?php echo e($candidate->gender == 'Other' ? 'selected' : ''); ?>>Other</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">DOB <span>*</span></label>
            <input type="date" class="form-control" id="" value="<?php echo e(date('Y-m-d',strtotime($candidate->date_of_birth)) ?? ''); ?>" name="dob"
                max="<?php echo e(date('Y-m-d')); ?>" placeholder="">
            <?php if($errors->has('dob')): ?>
                <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Age</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->age ?? ''); ?>"
                name="age" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Education</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->education ?? ''); ?>"
                name="education" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Other Education</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->other_education ?? ''); ?>"
                name="other_education" placeholder="">
        </div>
    </div>

    
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Mode of Registration</label>
            <input type="text" class="form-control" id=""
                value="<?php echo e($candidate->mode_of_registration ?? ''); ?>" name="mode_of_registration" placeholder="">
        </div>
    </div>
    

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Source</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->source ?? ''); ?>"
                name="source" placeholder="">
        </div>
    </div>

    

    <div class="col-lg-4">
        <div class="form-group referred_by_id" id="">

            <?php if($candidate->referred_by_id != null): ?>
                <label for="">Referred by <span><a href="javascript:void(0);"
                            class="referred_type">Other</a></span></label>
                <select name="referred_by_id" class="form-select" id="">
                    <option value="">Select Type</option>
                    <?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item['id']); ?>"
                            <?php echo e($candidate->referred_by_id == $item['id'] ? 'selected' : ''); ?>><?php echo e($item['full_name']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <label for="">Referred by <span><a href="javascript:void(0);"
                            class="referred_type">Associate</a></span></label>
                <input type="text" class="form-control" id="" value="<?php echo e($candidate->referred_by ?? ''); ?>"
                    name="referred_by" placeholder="">
            <?php endif; ?>

        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Religion: </label>
            <input type="text" class="form-control" id="" name="religion"
                value="<?php echo e($candidate->religion ?? ''); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Indian Driving License: </label>
            <input type="text" class="form-control" id="" name="indian_driving_license"
                value="<?php echo e($candidate->indian_driving_license ?? ''); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">International Driving License: </label>
            <input type="text" class="form-control" id="" name="international_driving_license"
                value="<?php echo e($candidate->international_driving_license ?? ''); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">English Speak</label>
            <select name="english_speak" class="form-select" id="">
                <option value="">Select Type</option>
                <option value="Basic" <?php echo e($candidate->english_speak == 'Basic' ? 'selected' : ''); ?>>Basic</option>
                <option value="Good" <?php echo e($candidate->english_speak == 'Good' ? 'selected' : ''); ?>>Good</option>
                <option value="Poor" <?php echo e($candidate->english_speak == 'Poor' ? 'selected' : ''); ?>>Poor</option>
                <option value="No" <?php echo e($candidate->english_speak == 'No' ? 'selected' : ''); ?>>No</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Arabic Speak</label>
            <select name="arabic_speak" class="form-select" id="">
                <option value="">Select Type</option>
                <option value="Basic" <?php echo e($candidate->english_speak == 'Basic' ? 'selected' : ''); ?>>Basic</option>
                <option value="Good" <?php echo e($candidate->english_speak == 'Good' ? 'selected' : ''); ?>>Good</option>
                <option value="Poor" <?php echo e($candidate->english_speak == 'Poor' ? 'selected' : ''); ?>>Poor</option>
                <option value="No" <?php echo e($candidate->english_speak == 'No' ? 'selected' : ''); ?>>No</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Return</label>
            <select name="return" class="form-select" id="">
                <option value="">Select Return Type</option>
                <option value="1" <?php echo e($candidate->return == '1' ? 'selected' : ''); ?>>Yes</option>
                <option value="0" <?php echo e($candidate->return == '0' ? 'selected' : ''); ?>>No</option>
            </select>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">ECR Type</label>
            <select name="ecr_type" class="form-select" id="">
                <option value="">Select ECR</option>
                <option value="ECR" <?php echo e($candidate->ecr_type == 'ECR' ? 'selected' : ''); ?>>ECR</option>
                <option value="ENCR" <?php echo e($candidate->ecr_type == 'ENCR' ? 'selected' : ''); ?>>ENCR</option>
            </select>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Position</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->position ?? ''); ?>"
                name="position" placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Indian Work Experience (If Any?)</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->indian_exp ?? ''); ?>"
                name="indian_exp" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Abroad Work Experience (If Any?)</label>
            <input type="text" class="form-control" id="" value="<?php echo e($candidate->abroad_exp ?? ''); ?>"
                name="abroad_exp" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Position Applied For</label>
            <input type="text" class="form-control" id=""
                value="<?php echo e($candidate->candidatePositions->name ?? ''); ?>" name="position_applied_for" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Last Update Date</label>
            <input type="date" class="form-control" id=""
                value="<?php echo e($candidate->last_update_date ?? ''); ?>" name="last_update_date" placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Status <span>*</span></label>
            <select name="cnadidate_status_id" class="form-select" id="">
                <option value="">Select A Status</option>
                <?php $__currentLoopData = $candidate_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->id); ?>"
                        <?php echo e($candidate->cnadidate_status_id == $status->id ? 'selected' : ''); ?>>
                        <?php echo e($status->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-lg-4">

    </div>
    <div class="col-lg-12">
        <div class="form-group">
            <label for="">Remarks</label>
            <textarea class="form-control" id="" rows="3" name="remark"><?php echo e($candidate->remarks ?? ''); ?></textarea>
        </div>
    </div>
<?php else: ?>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Full Name <span>*</span></label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('full_name')); ?>"
                name="full_name" placeholder="">
            <?php if($errors->has('full_name')): ?>
                <span class="text-danger"><?php echo e($errors->first('full_name')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Email <span></span></label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('email')); ?>" name="email"
                placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Alternative Contact No: </label>
            <input type="text" class="form-control" id="" name="alternate_contact_no"
                value="<?php echo e(old('alternate_contact_no')); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Whatsapp No: </label>
            <input type="text" class="form-control" id="" name="whatapp_no"
                value="<?php echo e(old('whatapp_no')); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">City: </label>
            <input type="text" class="form-control" id="" name="city" value="<?php echo e(old('city')); ?>"
                placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Gender</label>
            <select name="gender" class="form-select" id="">
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">DOB <span>*</span></label>
            <input type="date" class="form-control" id="" value="<?php echo e(old('dob')); ?>" name="dob"
                max="<?php echo e(date('Y-m-d')); ?>" placeholder="">
        </div>
        <?php if($errors->has('dob')): ?>
            <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
        <?php endif; ?>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Age</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('age')); ?>" name="age"
                placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Education</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('education')); ?>"
                name="education" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Other Education</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('other_education')); ?>"
                name="other_education" placeholder="">
        </div>
    </div>

    
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Mode of Registration</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('mode_of_registration')); ?>"
                name="mode_of_registration" placeholder="">
        </div>
    </div>
    

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Source</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('source')); ?>" name="source"
                placeholder="">
        </div>
    </div>

    

    <div class="col-lg-4">
        <div class="form-group referred_by_id" id="">
            <label for="">Referred by <span><a href="javascript:void(0);"
                        class="referred_type">Other</a></span></label>
            <select name="referred_by_id" class="form-select" id="">
                <option value="">Select Type</option>
                <?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item['id']); ?>"><?php echo e($item['full_name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Religion: </label>
            <input type="text" class="form-control" id="" name="religion"
                value="<?php echo e(old('religion')); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Indian Driving License: </label>
            <input type="text" class="form-control" id="" name="indian_driving_license"
                value="<?php echo e(old('indian_driving_license')); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">International Driving License: </label>
            <input type="text" class="form-control" id="" name="international_driving_license"
                value="<?php echo e(old('international_driving_license')); ?>" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">English Speak</label>
            <select name="english_speak" class="form-select" id="">
                <option value="">Select Type</option>
                <option value="Basic">Basic</option>
                <option value="Good">Good</option>
                <option value="Poor">Poor</option>
                <option value="No">No</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Arabic Speak</label>
            <select name="arabic_speak" class="form-select" id="">
                <option value="">Select Type</option>
                <option value="Basic">Basic</option>
                <option value="Good">Good</option>
                <option value="Poor">Poor</option>
                <option value="No">No</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Return</label>
            <select name="return" class="form-select" id="">
                <option value="">Select Return Type</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">ECR Type</label>
            <select name="ecr_type" class="form-select" id="">
                <option value="">Select ECR</option>
                <option value="ECR">ECR</option>
                <option value="ENCR">ENCR</option>
            </select>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Position</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('position')); ?>"
                name="position" placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Indian Work Experience (If Any?)</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('indian_exp')); ?>"
                name="indian_exp" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Abroad Work Experience (If Any?)</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('abroad_exp')); ?>"
                name="abroad_exp" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Position Applied For</label>
            <input type="text" class="form-control" id="" value="<?php echo e(old('position_applied_for')); ?>"
                name="position_applied_for" placeholder="">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Last Update Date</label>
            <input type="date" class="form-control" id="" value="<?php echo e(old('last_update_date')); ?>"
                name="last_update_date" placeholder="">
        </div>
    </div>

    <div class="col-lg-4">
        <div class="form-group">
            <label for="">Status<span>*</span></label>
            <select name="cnadidate_status_id" class="form-select" id="">
                <option value="">Select A Status</option>
                <?php $__currentLoopData = $candidate_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-lg-4">

    </div>
    <div class="col-lg-12">
        <div class="form-group">
            <label for="">Remarks</label>
            <textarea class="form-control" id="" rows="3" name="remark"><?php echo e(old('remark')); ?></textarea>
        </div>
    </div>

<?php endif; ?>
<?php /**PATH G:\new_xampp\htdocs\Al-hiraa\resources\views/candidates/auto-fill.blade.php ENDPATH**/ ?>