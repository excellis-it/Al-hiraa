<table class="table table-bordered mb-0 thead-border-top-0">
    <thead>
        <tr>
            <th>Company Name</th>
            <th>Candidate Interested In Interviews</th>
            <th>Candidate In Selection</th>
            <th>Candidate In Medical</th>
            <th>Candidate In Documentation</th>
            <th>Candidate In Deployment</th>
            <th>Total Service Charge</th>
            <th>Total Collection</th>
            <th>Vendor Service Charge</th>
            <th>Pending Collection</th>
        </tr>
    </thead>
    <tbody>
        @include('dashboard-job-interview-report-table')

    </tbody>
</table>
