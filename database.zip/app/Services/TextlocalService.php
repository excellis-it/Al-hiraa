<?php

namespace App\Services;

use GuzzleHttp\Client;

class TextlocalService
{
    protected $apiKey;
    protected $sender;

    public function __construct()
    {
        $this->apiKey = config('services.textlocal.api_key');
        $this->sender = config('services.textlocal.sender_id');
    }

    public function sendSms($numbers, $message)
    {
        $client = new Client();
        $url = 'https://api.textlocal.in/send/';

        $data = [
            'apikey' => $this->apiKey,
            'numbers' => implode(',', $numbers),
            'sender' => $this->sender,
            'message' => rawurlencode($message),
        ];
        // dd($data);
        try {
            $response = $client->post($url, [
                'form_params' => $data,
            ]);

            $body = json_decode($response->getBody(), true);

            if (isset($body['status']) && $body['status'] == 'success') {
                return $body;
            } else {
                return $body['errors'] ?? ['error' => 'Unknown error'];
            }
        } catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}
